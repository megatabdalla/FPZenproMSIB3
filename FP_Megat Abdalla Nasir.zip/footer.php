<style type="text/css">
  footer{
      background-color: #494949;
      color: white;
      font-family: Montserrat;
      width: 100%;
    }

  .page-footer {
    border-top: 1px solid #000;
  }
</style>
<br>
<span></span>
<footer class="page-footer font-small blue pt-4">
    <!-- Footer Links -->
    <div class="container-fluid text-md-left">
      <!-- Grid row -->
      <div class="row">
        <!-- Grid column -->
        <div class="col-md-6 mt-md-0 mt-3">
          <!-- Content -->
          <h5 class="text-uppercase">Contact Ust</h5>
          <p>Phone: 0811-5377-999<br>
             Jl. Mancasan Indah, Condongcatur, Depok, Kab. Sleman, DI Yogyakarta.</p>
        </div>
        <!-- Grid column -->
        <hr class="clearfix w-100 d-md-none pb-3">
        <!-- Grid column -->
        <div class="col-md-2 mb-md-0 mb-2">
          <!-- Links -->
          <h5 class="text-uppercase"><a href="#">Report</h5></a>
        </div>
        <!-- Grid column -->
        <div class="col-md-2 mb-md-0 mb-2">
          <!-- Links -->
          <h5 class="text-uppercase"><a href="#">Hak Cipta</h5></a>
        </div>
        <div class="col-md-2 mb-md-0 mb-2">
          <!-- Links -->
          <h5 class="text-uppercase"><a href="#">Tentang</h5></a>
        </div>
        <!-- Grid column -->
      </div>
      <!-- Grid row -->
    </div>
  </footer>
  <!-- Footer -->
  <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.2.2/dist/js/bootstrap.bundle.min.js"
    integrity="sha384-OERcA2EqjJCMA+/3y+gxIOqMEjwtxJY7qPCqsdltbNJuaOe923+mo//f6V8Qbsw3"
    crossorigin="anonymous"></script>
  <script src="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.2.0/js/all.min.js"
    integrity="sha512-naukR7I+Nk6gp7p5TMA4ycgfxaZBJ7MO5iC3Fp6ySQyKFHOGfpkSZkYVWV5R7u7cfAicxanwYQ5D1e17EfJcMA=="
    crossorigin="anonymous" referrerpolicy="no-referrer"></script>