<?php

namespace Mpdf\Tag;

class Bdi extends InlineTag
{


}
